<?php
define('DBHOST', '127.0.0.1');
define('DBNAME', 'art');
define('DBUSER', 'testuser2');
define('DBPASS', 'mypassword');
define('DBCONNSTRING','mysql:host=127.0.0.1;dbname=art');
?>