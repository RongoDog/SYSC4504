<?php
include 'includes/utils.php';
addToCart();
?>